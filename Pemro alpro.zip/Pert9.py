# Handle =  open('soal.txt', 'r') 
    

# for line in Handle:
#     question, answer = line.strip().split('||')
        
#     print(question.strip())
        
#     user_answer = input("Jawab: ").strip().lower()
        
#     if user_answer == answer.strip().lower():
#         print("Jawaban benar!")
#     else:
#         print("Jawaban salah!")
#     print()  
Handle = open('mbox-short.txt','r')

check = open('mbox.txt','r')

baris =  Handle.readlines()
lines = check.readlines()
for i in range(min(len(baris), len(lines))):
        line1 = baris[i].strip()
        line2 = lines[i].strip()
        if line1 != line2:
            print(f"Perbedaan pada baris {i + 1}:")
            print(f"{Handle}: {line1}")
            print(f"{check}: {line2}")
            print()

Handle.close()
check.close()