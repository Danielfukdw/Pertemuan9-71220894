handle = open('mbox.txt','r')
check = open('mbox-short.txt', 'r')

for i in handle:
    for j in  check:
        if i != j :
            print(i)
                    
